from pathlib import Path
from zipfile import ZipFile

# if no file then it ll create one
with ZipFile("files.zip", "w") as zip:
    for path in Path("direcory").rglob("*.*"):
        zip.write(path)


# with ZipFile("files.zip") as zip:
#     print(zip.namelist())
